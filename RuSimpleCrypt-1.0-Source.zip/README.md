# SimpleCrypt
SimpleCrypt X is the next version of SimpleCrypt
